<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Discussion Forum</title>
<link rel="stylesheet" href="css/index.css" />
<?php
include_once"setting/eforum_navigation.php";
?>
</head>

<body>
<p class="p1">Discussion Forum</p>
<p class="p3">Please login to see the content.</p>
<br><br><br><br>
</body>
</html>